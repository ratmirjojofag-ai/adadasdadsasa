# Worldender 1.5.0 build workspace

Targets:
- Forge 1.20.1 (Java 17)
- NeoForge 1.21.1 (Java 21)

## Build
GitHub Actions workflow `.github/workflows/build.yml` builds both targets and uploads the JARs as artifacts.

## Important
The Forge project is the 1.5.0 Forge target.
The NeoForge project is a 1.5.0 port target; it still requires compile-time reconciliation against NeoForge 1.21.1 APIs before claiming a successful build. The CI is intentionally included so the exact compiler failures are surfaced.

NeoForge 1.20.1 is not included.
