# Worldender 1.5.0 — Forge 1.20.1

Forge 1.20.1 port with optional Mekanism, Create, Create New Age, Applied Energistics 2, JEI and Jade compatibility.

# Worldender Device — Forge 1.20.1

Forge port of Worldender Device 1.3.x, focused on Minecraft 1.20.1.

## Main additions carried into the Forge port

- Zeta Device and Alpha Stabilizer.
- `StartDeletingWorld` gamerule: an autonomous deletion front starting from X=0 Z=0.
- Progression: 10 blocks/min before day 5, 30 from day 5, 45 from day 20, 60 from day 35.
- Multiple power generators: solar, wind, water, thermal, combustion, fusion, singularity.
- Energy furnaces: standard, induction and plasma.
- Energy storage: capacitor, bank, quantum bank and portable FE cells.
- Energy network: cables, relays and transformer.
- Pulverizer, recycler, repair station, shield generator, chrono anchor and utility tools.
- Eight advanced ores: cobalt, titanium, uranium, iridium, osmium, lithium, thorium and aetherite.
- Overclock module, World Scanner and Energy Magnet.

## Commands

```text
/gamerule StartDeletingWorld true
/worldender status
/worldender StartDeletingWorld true
/worldender StartDeletingWorld false
/worldender radius <value>
/worldender radius auto
```

## Build

Use Java 17 with Forge 1.20.1. The project uses official Mojang mappings and ForgeGradle 6.x.

```text
gradle build
```

The development environment needs to be online at least once so Gradle can download Forge and Minecraft dependencies.


## Platform compatibility

This port targets Minecraft **1.20.1 + Forge 47.x**. It keeps the enhanced Worldender gameplay: autonomous `StartDeletingWorld`, Zeta/Alpha devices, the energy network, generators, energy storage, machines, portable cells, scanners, magnet, overclock module and eight new ores.

Forge is the primary 1.20.1 target. NeoForge 1.20.1 is intentionally not used for this build because NeoForge recommends Forge for 1.20.1.


## Optional compatibility (Forge 1.20.1)

Worldender 1.4.0 Forge 1.20.1 Compat exposes Forge Energy (`ForgeCapabilities.ENERGY`) from all Worldender energy block entities, including the energy cable, and from all portable energy cells. This makes the power system usable by Forge energy networks and machines.

### Mekanism
Mekanism Universal Cables can transfer power to/from Worldender FE blocks and portable cells. The custom ore outputs are also registered into Forge ore/raw/ingot tag families where applicable. An alternative high-capacity cell recipe is available when Mekanism is installed.

### Applied Energistics 2
Worldender storage/generator blocks and energy cells expose Forge Energy. Use an AE2 energy acceptor or another AE2 component that converts Forge Energy to feed the AE2 power network. An AE2-material alternative recipe for Quantum Cell is included.

### Create
The new **Create Kinetic Dynamo** scans the nearby Create kinetic network (up to 3 blocks away) for a kinetic block entity and converts their rotation speed into Worldender FE. It is deliberately reflection-based, so Worldender does not hard-depend on a particular Create 1.20.1 patch version.

### Create New Age
When `create_new_age` is present, Worldender registers an ESL `EnergyStorage` adapter for its energy block entity type. This lets Create New Age electrical connectors discover Worldender generators, cables, storage and machines directly. Transaction snapshots are supported so network simulations/rollbacks do not duplicate or destroy energy. A Create New Age material recipe for the Energy Core is included.

All four integrations are optional: the base mod still loads without Mekanism, AE2, Create or Create New Age.

### JEI + Jade + GUI

- Optional **JEI 15.20.0.127** integration for Forge 1.20.1. Existing Worldender datapack recipes appear in JEI; the compat also adds machine catalysts and energy-cell info.
- Optional **Jade 11.13.3+forge** integration. Looking at a Worldender energy block shows FE stored/capacity, generation, machine progress and overclock state.
- New client dashboard GUI for energy generators, storage, machines, Zeta Device and Alpha Device. Sneak + right-click on Zeta/Alpha activates them; normal right-click opens the dashboard.
- Energy machines now expose functional input/output slots through the dashboard; shift-click transfer to input is supported.
