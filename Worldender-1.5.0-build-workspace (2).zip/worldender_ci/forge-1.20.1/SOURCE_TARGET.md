# Worldender 1.5.0 — Forge 1.20.1

Target: Minecraft **1.20.1** + Forge **47.x**, Java **17**.

Includes the 1.5.0 energy system, machines, ores, Zeta/Alpha mechanics, StartDeletingWorld, JEI/Jade and optional Mekanism / Create / Create New Age / AE2 compatibility prepared for the Forge 1.20.1 line.

This archive deliberately contains **no NeoForge 1.20.1 target**.
