# Worldender 1.4.0 Forge 1.20.1 Compatibility Build

Implemented:
- Forge Energy capability on Worldender energy block entities.
- Forge Energy capability on portable EnergyItem cells.
- Energy cable upgraded to a real energy-network block entity.
- Create kinetic dynamo via reflection, supporting Create without a hard dependency.
- Create New Age ESL transactional adapter (optional compile/runtime integration).
- Optional dependency metadata for Mekanism, AE2, Create and Create New Age.
- Forge ore/raw/ingot tags for the eight Worldender metals.
- Create-only recipe for the kinetic dynamo.

Build note:
- Full Gradle/FML compilation was not run in this environment because Gradle/Forge/Maven dependencies are not available locally and external downloads are unavailable.
- JSON and source-level static checks were run after editing.

Alternative compatibility recipes were added for Mekanism, AE2 and Create New Age. Create Kinetic Dynamo scans a 7x5x7 neighborhood for Create kinetic block entities.


## 1.5.0 GUI / JEI / Jade pass
- Added optional JEI API/runtime wiring and a JEI plugin.
- Added optional Jade API/runtime wiring and a server-synced energy telemetry provider.
- Added custom EnergyMachineMenu + client dashboard screen.
- Energy machine input/output are now represented by real menu slots; normal right-click opens the dashboard.
- Added custom pixel-tech GUI texture and RU/EN strings.


## 1.5.0 JEI + Jade + GUI pass
- Optional JEI 15.20.0.127 compile/runtime development wiring.
- Optional Jade 11.13.3+forge compile/runtime development wiring.
- Jade shows stored/capacity FE, generation, machine progress, overclock, Zeta countdown/radius and Alpha stabilizer state.
- JEI plugin adds Energy Cell and Quantum Cell info; all normal Worldender datapack crafting recipes remain discoverable by JEI automatically.
- Custom EnergyMachineMenu and EnergyMachineScreen with synced energy/progress and real machine input/output slots.
- Zeta/Alpha now open a dashboard normally; sneak-right-click activates them.
- Custom 320x220 pixel-tech dashboard background.

Build note: the project could not be executed in this sandbox because ForgeGradle/Minecraft dependencies are not cached and external Maven DNS/network access is unavailable. Static JSON/resource validation passes.
