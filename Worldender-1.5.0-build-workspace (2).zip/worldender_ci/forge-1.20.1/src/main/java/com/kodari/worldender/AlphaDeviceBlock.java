package com.kodari.worldender;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkHooks;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

public final class AlphaDeviceBlock extends Block implements EntityBlock {
    public AlphaDeviceBlock(BlockBehaviour.Properties properties) { super(properties); }
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return new AlphaDeviceBlockEntity(pos, state); }
    @Override public <T extends BlockEntity> @Nullable BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (type != WorldenderMod.ALPHA_ENTITY.get()) return null; return (lvl, p, s, be) -> AlphaDeviceBlockEntity.tick(lvl, p, s, (AlphaDeviceBlockEntity) be);
    }
    @Override public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(level.getBlockEntity(pos) instanceof AlphaDeviceBlockEntity entity)) return InteractionResult.PASS;
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (player.isCrouching()) {
            if (entity.activate()) player.displayClientMessage(Component.literal("Alpha Stabilizer active for 30 seconds."), true);
            else player.displayClientMessage(Component.literal("Alpha needs 2,500,000 FE."), true);
        } else if (player instanceof ServerPlayer serverPlayer) {
            NetworkHooks.openScreen(serverPlayer, new net.minecraft.world.SimpleMenuProvider(
                    (id, inventory, p) -> new EnergyMachineMenu(id, inventory, pos, EnergyMachineMenu.MODE_ALPHA),
                    Component.literal("ALPHA DEVICE")), buf -> buf.writeBlockPos(pos).writeVarInt(EnergyMachineMenu.MODE_ALPHA));
        }
        return InteractionResult.SUCCESS;
    }
}
