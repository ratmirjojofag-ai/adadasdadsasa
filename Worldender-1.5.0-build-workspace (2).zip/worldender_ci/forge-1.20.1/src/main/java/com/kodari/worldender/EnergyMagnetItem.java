package com.kodari.worldender;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;

public final class EnergyMagnetItem extends Item {
    public EnergyMagnetItem(Properties properties) { super(properties); }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player user, InteractionHand hand) {
        ItemStack stack = user.getItemInHand(hand);
        if (!level.isClientSide && level instanceof ServerLevel server) {
            for (ItemEntity entity : server.getEntitiesOfClass(ItemEntity.class, user.getBoundingBox().inflate(10), e -> !e.isRemoved())) {
                double dx = user.getX() - entity.getX(), dy = user.getY() + 0.6 - entity.getY(), dz = user.getZ() - entity.getZ(); double distance = Math.sqrt(dx*dx + dy*dy + dz*dz); if (distance < 0.01) continue;
                double strength = Math.max(0.02, (1.0 - Math.min(1.0, distance / 10.0)) * 0.35); entity.setDeltaMovement(entity.getDeltaMovement().add(dx / distance * strength, dy / distance * strength, dz / distance * strength));
            }
            stack.hurtAndBreak(1, user, p -> p.broadcastBreakEvent(hand)); return InteractionResultHolder.sidedSuccess(stack, false);
        }
        return InteractionResultHolder.success(stack);
    }
}
