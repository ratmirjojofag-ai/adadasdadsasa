package com.kodari.worldender;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkHooks;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

public final class DeviceBlock extends Block implements EntityBlock {
    public DeviceBlock(BlockBehaviour.Properties properties) { super(properties); }
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return new DeviceBlockEntity(pos, state); }
    @Override public <T extends BlockEntity> @Nullable BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (type != WorldenderMod.DEVICE_ENTITY.get()) return null; return (lvl, p, s, be) -> DeviceBlockEntity.tick(lvl, p, s, (DeviceBlockEntity) be);
    }
    @Override public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(level.getBlockEntity(pos) instanceof DeviceBlockEntity device)) return InteractionResult.PASS;
        if (level.isClientSide) return InteractionResult.SUCCESS;
        ItemStack held = player.getItemInHand(hand);
        if (held.getItem() instanceof EnergyItem item) {
            long amount = Math.min(item.getCapacity() - item.getEnergy(held), device.getEnergy());
            if (amount > 0) { long extracted = device.extractEnergy(amount, true); long stored = item.receive(held, extracted); device.extractEnergy(stored, false); }
            player.displayClientMessage(Component.literal("Zeta charge: " + device.getEnergy() + " / " + device.getCapacity() + " FE"), true);
            return InteractionResult.SUCCESS;
        }
        if (held.isEmpty()) {
            if (player.isCrouching()) {
                if (device.activate()) player.displayClientMessage(Component.literal("ZETA WAVE ARMED — countdown started."), true);
                else player.displayClientMessage(Component.literal("Need 1,000,000 FE to activate Zeta."), true);
            } else if (player instanceof ServerPlayer serverPlayer) {
                NetworkHooks.openScreen(serverPlayer, new net.minecraft.world.SimpleMenuProvider(
                        (id, inventory, p) -> new EnergyMachineMenu(id, inventory, pos, EnergyMachineMenu.MODE_ZETA),
                        Component.literal("ZETA DEVICE")), buf -> buf.writeBlockPos(pos).writeVarInt(EnergyMachineMenu.MODE_ZETA));
            }
            return InteractionResult.SUCCESS;
        }
        return InteractionResult.PASS;
    }
}
