package com.kodari.worldender;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;

public final class AlphaDeviceBlockEntity extends BlockEntity implements EnergyStorage {
    private long energy; private int activeTicks;
    public AlphaDeviceBlockEntity(BlockPos pos, BlockState state) { super(WorldenderMod.ALPHA_ENTITY.get(), pos, state); }
    @Override public long getEnergy() { return energy; }
    @Override public long getCapacity() { return 2_500_000L; }
    @Override public long receiveEnergy(long amount, boolean simulate) { long accepted = Math.min(Math.max(0L, amount), getCapacity() - energy); if (!simulate && accepted > 0) { energy += accepted; setChanged(); } return accepted; }
    @Override public long extractEnergy(long amount, boolean simulate) { long taken = Math.min(Math.max(0L, amount), energy); if (!simulate && taken > 0) { energy -= taken; setChanged(); } return taken; }
    public boolean isActive() { return activeTicks > 0; }
    public boolean activate() { if (activeTicks > 0 || energy < getCapacity()) return false; energy = 0; activeTicks = 600; setChanged(); return true; }
    public static void tick(Level level, BlockPos pos, BlockState state, AlphaDeviceBlockEntity entity) {
        if (!(level instanceof ServerLevel server) || entity.activeTicks <= 0) return;
        entity.activeTicks--; DeletionEngine.updateAlphaStabilizer(server, pos, true);
        if (entity.activeTicks % 20 == 0) entity.setChanged();
        if (entity.activeTicks == 0) DeletionEngine.updateAlphaStabilizer(server, pos, false);
    }
    @Override protected void saveAdditional(CompoundTag tag) { super.saveAdditional(tag); tag.putLong("Energy", energy); tag.putInt("Active", activeTicks); }
    @Override public void load(CompoundTag tag) { super.load(tag); energy = Math.max(0L, tag.getLong("Energy")); activeTicks = Math.max(0, tag.getInt("Active")); }
}
