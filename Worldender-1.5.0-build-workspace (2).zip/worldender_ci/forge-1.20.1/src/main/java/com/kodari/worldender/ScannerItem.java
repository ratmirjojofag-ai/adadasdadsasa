package com.kodari.worldender;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public final class ScannerItem extends Item {
    public ScannerItem(Properties properties) { super(properties); }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player user, InteractionHand hand) {
        ItemStack scanner = user.getItemInHand(hand); if (!level.isClientSide && level instanceof ServerLevel server) {
            int radius = DeletionEngine.getRadius(server), speed = DeletionEngine.getSpeed(server); user.displayClientMessage(Component.literal("World Scanner"), false);
            user.displayClientMessage(Component.literal("Origin wave: " + radius + " radius | " + speed + " blocks/min | day " + DeletionEngine.getDays(server)), false);
            user.displayClientMessage(Component.literal("Energy nodes in 8 blocks: " + countNearbyEnergyBlocks(server, user.blockPosition())), false); scanner.hurtAndBreak(1, user, p -> p.broadcastBreakEvent(hand)); return InteractionResultHolder.sidedSuccess(scanner, false);
        }
        return InteractionResultHolder.success(scanner);
    }
    private int countNearbyEnergyBlocks(ServerLevel world, BlockPos center) { int found = 0; for (BlockPos pos : BlockPos.betweenClosed(center.offset(-8, -4, -8), center.offset(8, 4, 8))) { if (world.getBlockEntity(pos) instanceof EnergyStorage) found++; if (found >= 128) break; } return found; }
}
