package com.kodari.worldender.client;

import com.kodari.worldender.EnergyBlockEntity;
import com.kodari.worldender.EnergyKind;
import com.kodari.worldender.EnergyMachineMenu;
import com.kodari.worldender.WorldenderMod;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

public final class EnergyMachineScreen extends AbstractContainerScreen<EnergyMachineMenu> {
    private static final ResourceLocation BG = new ResourceLocation(WorldenderMod.MOD_ID, "textures/gui/energy_dashboard.png");

    public EnergyMachineScreen(EnergyMachineMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = 320;
        imageHeight = 220;
        inventoryLabelX = 30;
        inventoryLabelY = 108;
    }

    @Override protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int left = (width - imageWidth) / 2;
        int top = (height - imageHeight) / 2;
        g.blit(BG, left, top, 0, 0, imageWidth, imageHeight, imageWidth, imageHeight);

        BlockEntity be = minecraft.level == null ? null : minecraft.level.getBlockEntity(menu.getPos());
        String name = getMachineName(be);
        long energy = menu.getEnergy();
        long capacity = Math.max(1L, menu.getCapacity());
        double pct = Math.min(1.0, energy / (double) capacity);

        g.drawString(font, Component.literal(name), left + 18, top + 12, 0xEAF9FF, false);
        g.drawString(font, Component.literal(menu.getMode() == EnergyMachineMenu.MODE_ZETA ? "WORLDENDER CORE" : menu.getMode() == EnergyMachineMenu.MODE_ALPHA ? "STABILIZATION CORE" : "ENERGY MATRIX"), left + 18, top + 27, 0x7ED8FF, false);

        // Energy meter
        int bx = left + 18, by = top + 49, bw = 284, bh = 16;
        g.fill(bx, by, bx + bw, by + bh, 0xFF07131C);
        int fill = (int)(bw * pct);
        if (fill > 0) g.fill(bx + 2, by + 2, bx + fill - 2, by + bh - 2, 0xFF39D7FF);
        g.fill(bx + Math.max(2, fill - 2), by + 2, bx + Math.max(2, fill), by + bh - 2, 0xFFE7FFFF);
        g.drawString(font, Component.literal(formatFE(energy) + " / " + formatFE(capacity) + " FE"), bx + 8, by + 4, 0x08151B, false);

        // State badge / progress
        if (menu.getMode() == EnergyMachineMenu.MODE_ENERGY) {
            int progress = menu.getProgress(), max = menu.getMachineTime();
            boolean machine = max > 0;
            String status = machine ? (progress >= max ? "READY" : progress > 0 ? "PROCESSING" : "IDLE") : getEnergyStatus(be);
            g.drawString(font, Component.literal(status), left + 18, top + 79, status.equals("PROCESSING") ? 0x55F7FF : 0xC8D7E0, false);
            if (machine) {
                int px = left + 102, py = top + 77, pw = 180, ph = 10;
                g.fill(px, py, px + pw, py + ph, 0xFF07131C);
                int pfill = Math.min(pw, (int)(pw * Math.min(1d, progress / (double)Math.max(1, max))));
                if (pfill > 0) g.fill(px + 1, py + 1, px + pfill - 1, py + ph - 1, 0xFF8A6CFF);
                g.drawString(font, Component.literal(progress + " / " + max + " ticks"), px + 6, py + 1, 0xE8E7FF, false);
            }
        } else {
            String state = menu.getMode() == EnergyMachineMenu.MODE_ZETA ? "ORIGIN DELETION ENGINE" : "ORIGIN STABILIZER";
            g.drawString(font, Component.literal(state), left + 18, top + 79, 0xFF83D9, false);
        }

        // machine slots
        if (menu.getMode() == EnergyMachineMenu.MODE_ENERGY && menu.slots.size() >= 2) {
            drawSlotFrame(g, left + 103, top + 68);
            drawSlotFrame(g, left + 189, top + 68);
            g.drawString(font, Component.literal("INPUT"), left + 99, top + 103, 0x7E92A1, false);
            g.drawString(font, Component.literal("OUTPUT"), left + 183, top + 103, 0x7E92A1, false);
        }

        // bottom telemetry strip
        long pulse = (minecraft.level == null ? 0L : minecraft.level.getGameTime()) % 120L;
        int glowX = left + 18 + (int)(pulse * 2.2f);
        if (glowX < left + 302) g.fill(glowX, top + 210, glowX + 12, top + 212, 0xFF4CE6FF);
    }

    private void drawSlotFrame(GuiGraphics g, int x, int y) {
        g.fill(x, y, x + 18, y + 18, 0xFF0A1720);
        g.fill(x + 1, y + 1, x + 17, y + 17, 0xFF163241);
        g.fill(x + 2, y + 2, x + 16, y + 3, 0xFF5EEBFF);
        g.fill(x + 2, y + 16, x + 16, y + 17, 0xFF1A6479);
    }

    private String getMachineName(BlockEntity be) {
        if (menu.getMode() == EnergyMachineMenu.MODE_ZETA) return "ZETA DEVICE";
        if (menu.getMode() == EnergyMachineMenu.MODE_ALPHA) return "ALPHA DEVICE";
        if (be instanceof EnergyBlockEntity e) return switch (e.kind()) {
            case SOLAR -> "SOLAR ARRAY"; case WIND -> "WIND TURBINE"; case WATER -> "HYDRO CORE"; case THERMAL -> "THERMAL GENERATOR";
            case COMBUSTION -> "COMBUSTION GENERATOR"; case FUSION -> "FUSION REACTOR"; case SINGULARITY -> "SINGULARITY REACTOR";
            case FURNACE -> "ENERGY FURNACE"; case INDUCTION_FURNACE -> "INDUCTION FURNACE"; case PLASMA_FURNACE -> "PLASMA FURNACE";
            case PULVERIZER -> "ORE PULVERIZER"; case RECYCLER -> "MATTER RECYCLER"; case REPAIR -> "REPAIR STATION";
            case SHIELD -> "SHIELD GENERATOR"; case CHRONO -> "CHRONO ANCHOR"; case CAPACITOR -> "ENERGY CAPACITOR";
            case BANK -> "ENERGY BANK"; case QUANTUM_BANK -> "QUANTUM BANK"; case RELAY -> "ENERGY RELAY";
            case TRANSFORMER -> "ENERGY TRANSFORMER"; case WORKBENCH -> "CELL WORKBENCH"; case KINETIC -> "KINETIC DYNAMO";
        };
        return "WORLDENDER MODULE";
    }

    private String getEnergyStatus(BlockEntity be) {
        if (!(be instanceof EnergyBlockEntity e)) return "ONLINE";
        if (e.kind().isGenerator()) return "GENERATING";
        if (e.kind().isStorage()) return "STANDBY STORAGE";
        return "ONLINE";
    }

    private String formatFE(long value) {
        if (value >= 1_000_000_000L) return String.format("%.2fG", value / 1_000_000_000d);
        if (value >= 1_000_000L) return String.format("%.2fM", value / 1_000_000d);
        if (value >= 1_000L) return String.format("%.1fk", value / 1_000d);
        return Long.toString(value);
    }

    @Override protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        // Custom background already renders all labels.
        if (menu.getMode() == EnergyMachineMenu.MODE_ENERGY) {
            g.drawString(font, Component.literal("PLAYER INVENTORY"), inventoryLabelX, inventoryLabelY, 0x7E92A1, false);
        }
    }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        super.render(g, mouseX, mouseY, partialTick);
        renderTooltip(g, mouseX, mouseY);
    }
}
