package com.kodari.worldender;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkHooks;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

public final class EnergyBlock extends Block implements EntityBlock {
    private final EnergyKind kind;
    public EnergyBlock(EnergyKind kind, BlockBehaviour.Properties properties) { super(properties); this.kind = kind; }
    public EnergyKind kind() { return kind; }
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return new EnergyBlockEntity(pos, state); }
    @Override public <T extends BlockEntity> @Nullable BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (type != WorldenderMod.ENERGY.get()) return null;
        return (lvl, p, s, be) -> EnergyBlockEntity.tick(lvl, p, s, (EnergyBlockEntity) be);
    }
    @Override public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(level.getBlockEntity(pos) instanceof EnergyBlockEntity be)) return InteractionResult.PASS;
        if (level.isClientSide) return InteractionResult.SUCCESS;
        ItemStack held = player.getItemInHand(InteractionHand.MAIN_HAND);
        if (held.is(WorldenderMod.OVERCLOCK_MODULE.get())) {
            if (!kind.isMachine() && !kind.isGenerator()) return InteractionResult.PASS;
            if (be.enableOverclock(20 * 30)) {
                if (!player.getAbilities().instabuild) held.shrink(1);
                player.displayClientMessage(Component.literal("Overclock engaged: x2 output/speed for 30 seconds."), true);
                return InteractionResult.SUCCESS;
            }
        }
        if (held.getItem() instanceof EnergyItem energyItem) {
            long itemEnergy = energyItem.getEnergy(held);
            long free = be.getCapacity() - be.getEnergy();
            long toMachine = Math.min(itemEnergy, Math.min(free, 100_000L));
            if (toMachine > 0L) {
                long accepted = be.receiveEnergy(toMachine, false);
                energyItem.extract(held, accepted);
                player.displayClientMessage(Component.literal("Transferred " + accepted + " FE to " + kind.name()), true);
                return InteractionResult.SUCCESS;
            }
            long before = energyItem.getEnergy(held);
            long moved = 0L;
            if (be.getEnergy() > 0L) {
                long extracted = be.extractEnergy(Math.min(100_000L, energyItem.getCapacity() - before), true);
                if (extracted > 0L) {
                    long stored = energyItem.receive(held, extracted);
                    be.extractEnergy(stored, false);
                    moved = stored;
                }
            }
            if (moved == 0L) moved = EnergyNetwork.pullIntoItem((net.minecraft.server.level.ServerLevel) level, pos, held, Math.min(100_000L, energyItem.getCapacity() - before));
            player.displayClientMessage(Component.literal("Energy: " + energyItem.getEnergy(held) + " / " + energyItem.getCapacity() + " FE"), true);
            return moved > 0L ? InteractionResult.SUCCESS : InteractionResult.PASS;
        }
        if (held.isEmpty()) {
            if (player instanceof ServerPlayer serverPlayer) {
                NetworkHooks.openScreen(serverPlayer, new net.minecraft.world.SimpleMenuProvider(
                        (id, inventory, p) -> new EnergyMachineMenu(id, inventory, pos, EnergyMachineMenu.MODE_ENERGY),
                        Component.literal(kind.name())), buf -> buf.writeBlockPos(pos).writeVarInt(EnergyMachineMenu.MODE_ENERGY));
            }
            return InteractionResult.SUCCESS;
        }
        if (kind.isMachine()) {
            boolean inserted = be.insertInput(held);
            if (inserted && !player.getAbilities().instabuild) held.shrink(1);
            return inserted ? InteractionResult.SUCCESS : InteractionResult.PASS;
        }
        return InteractionResult.PASS;
    }
}
