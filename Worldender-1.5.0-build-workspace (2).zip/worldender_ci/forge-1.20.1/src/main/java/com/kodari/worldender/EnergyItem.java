package com.kodari.worldender;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.Direction;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.energy.IEnergyStorage;

public class EnergyItem extends Item {
    private static final String ENERGY_TAG = "WorldenderEnergy";
    private final long capacity;
    public EnergyItem(long capacity, Properties properties) { super(properties); this.capacity = capacity; }
    public long getCapacity() { return capacity; }
    public long getEnergy(ItemStack stack) { CompoundTag tag = stack.getTag(); return tag == null ? 0L : Math.max(0L, Math.min(capacity, tag.getLong(ENERGY_TAG))); }
    private void setEnergy(ItemStack stack, long energy) { stack.getOrCreateTag().putLong(ENERGY_TAG, Math.max(0L, Math.min(capacity, energy))); }
    public long receive(ItemStack stack, long amount) { long accepted = Math.min(Math.max(0L, amount), capacity - getEnergy(stack)); if (accepted > 0) setEnergy(stack, getEnergy(stack) + accepted); return accepted; }
    public long extract(ItemStack stack, long amount) { long taken = Math.min(Math.max(0L, amount), getEnergy(stack)); if (taken > 0) setEnergy(stack, getEnergy(stack) - taken); return taken; }

    @Override public ICapabilityProvider initCapabilities(ItemStack stack, CompoundTag nbt) {
        return new ICapabilityProvider() {
            private final LazyOptional<IEnergyStorage> capability = LazyOptional.of(() -> new IEnergyStorage() {
                @Override public int receiveEnergy(int maxReceive, boolean simulate) {
                    if (maxReceive <= 0) return 0;
                    long accepted = Math.min((long) maxReceive, capacity - getEnergy(stack));
                    if (!simulate && accepted > 0) EnergyItem.this.receive(stack, accepted);
                    return (int) accepted;
                }
                @Override public int extractEnergy(int maxExtract, boolean simulate) {
                    if (maxExtract <= 0) return 0;
                    long taken = Math.min((long) maxExtract, getEnergy(stack));
                    if (!simulate && taken > 0) EnergyItem.this.extract(stack, taken);
                    return (int) taken;
                }
                @Override public int getEnergyStored() { return (int) Math.min(Integer.MAX_VALUE, getEnergy(stack)); }
                @Override public int getMaxEnergyStored() { return (int) Math.min(Integer.MAX_VALUE, capacity); }
                @Override public boolean canExtract() { return true; }
                @Override public boolean canReceive() { return true; }
            });
            @Override public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction side) {
                return cap == ForgeCapabilities.ENERGY ? capability.cast() : LazyOptional.empty();
            }
        };
    }

    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand); if (!level.isClientSide && level instanceof ServerLevel server) {
            long request = Math.min(50_000L, capacity - getEnergy(stack)); long moved = request > 0 ? EnergyNetwork.pull(server, player.blockPosition(), request) : 0; if (moved > 0) receive(stack, moved);
            player.displayClientMessage(Component.literal("Energy: " + getEnergy(stack) + " / " + capacity + " FE"), true); return InteractionResultHolder.sidedSuccess(stack, false);
        }
        return InteractionResultHolder.success(stack);
    }
    @Override public boolean isBarVisible(ItemStack stack) { return true; }
    @Override public int getBarWidth(ItemStack stack) { return (int)Math.round(13.0 * getEnergy(stack) / (double)Math.max(1L, capacity)); }
    @Override public int getBarColor(ItemStack stack) { return 0x33CCFF; }
}
