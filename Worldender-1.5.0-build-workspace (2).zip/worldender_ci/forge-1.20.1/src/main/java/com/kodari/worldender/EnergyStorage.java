package com.kodari.worldender;

public interface EnergyStorage {
    long getEnergy();
    long getCapacity();
    long receiveEnergy(long amount, boolean simulate);
    long extractEnergy(long amount, boolean simulate);
}
