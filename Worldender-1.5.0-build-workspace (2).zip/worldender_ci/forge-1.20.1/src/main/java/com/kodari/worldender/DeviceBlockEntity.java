package com.kodari.worldender;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;

public final class DeviceBlockEntity extends BlockEntity implements EnergyStorage {
    private long energy; private int countdown = -1; private int radius;
    public DeviceBlockEntity(BlockPos pos, BlockState state) { super(WorldenderMod.DEVICE_ENTITY.get(), pos, state); }
    @Override public long getEnergy() { return energy; }
    @Override public long getCapacity() { return 1_000_000L; }
    @Override public long receiveEnergy(long amount, boolean simulate) { long accepted = Math.min(Math.max(0L, amount), getCapacity() - energy); if (!simulate && accepted > 0) { energy += accepted; setChanged(); } return accepted; }
    @Override public long extractEnergy(long amount, boolean simulate) { long taken = Math.min(Math.max(0L, amount), energy); if (!simulate && taken > 0) { energy -= taken; setChanged(); } return taken; }
    public int getCountdown() { return countdown; }
    public int getRadius() { return radius; }
    public boolean activate() { if (countdown >= 0 || energy < getCapacity()) return false; countdown = 1_200; setChanged(); return true; }
    public static void tick(Level level, BlockPos pos, BlockState state, DeviceBlockEntity entity) {
        if (!(level instanceof ServerLevel server)) return;
        if (entity.countdown >= 0) {
            if (entity.countdown > 0) { entity.countdown--; if (entity.countdown % 200 == 0) entity.setChanged(); return; }
            entity.radius = Math.min(30_000_000, entity.radius + 16); DeletionEngine.eraseLoadedFront(server, entity.radius, 16); if (entity.radius >= 30_000_000) entity.countdown = -1; entity.setChanged(); return;
        }
        long request = Math.max(0L, entity.getCapacity() - entity.energy);
        if (request > 0) entity.energy = Math.min(entity.getCapacity(), entity.energy + EnergyNetwork.pull(server, pos, Math.min(25_000L, request)));
    }
    @Override protected void saveAdditional(CompoundTag tag) { super.saveAdditional(tag); tag.putLong("Energy", energy); tag.putInt("Countdown", countdown); tag.putInt("Radius", radius); }
    @Override public void load(CompoundTag tag) { super.load(tag); energy = Math.max(0L, tag.getLong("Energy")); countdown = tag.getInt("Countdown"); radius = Math.max(0, tag.getInt("Radius")); }
}
