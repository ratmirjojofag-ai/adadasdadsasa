package com.kodari.worldender;

import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.OreFeature;
import net.minecraft.world.level.levelgen.feature.configurations.OreConfiguration;
import net.minecraft.world.level.levelgen.placement.BiomeFilter;
import net.minecraft.world.level.levelgen.placement.CountPlacement;
import net.minecraft.world.level.levelgen.placement.HeightRangePlacement;
import net.minecraft.world.level.levelgen.placement.InSquarePlacement;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.levelgen.VerticalAnchor;
import net.minecraft.world.level.levelgen.OreFeatures;
import net.minecraftforge.event.world.BiomeLoadingEvent;

import java.util.List;

public final class WorldGeneration {
    private static final int[] VEIN_SIZES = {7, 6, 5, 4, 6, 7, 5, 3};
    private static final int[] COUNTS = {10, 8, 5, 3, 8, 7, 4, 1};
    private static final int[] MIN_Y = {-32, -48, -64, -48, -32, -8, -48, -64};
    private static final int[] MAX_Y = {48, 32, 16, 0, 32, 80, 8, -40};
    private WorldGeneration() {}

    public static void addOres(BiomeLoadingEvent event) {
        ResourceLocation name = event.getName();
        if (name != null && (name.getPath().contains("nether") || name.getPath().contains("end"))) return;
        for (int i = 0; i < WorldenderMod.ORE_BLOCKS.length; i++) {
            ConfiguredFeature<OreConfiguration, OreFeature> configured = new ConfiguredFeature<>(Feature.ORE,
                    new OreConfiguration(List.of(
                            OreConfiguration.target(OreFeatures.STONE_ORE_REPLACEABLES, WorldenderMod.ORE_BLOCKS[i].get().defaultBlockState()),
                            OreConfiguration.target(OreFeatures.DEEPSLATE_ORE_REPLACEABLES, WorldenderMod.ORE_BLOCKS[i].get().defaultBlockState())), VEIN_SIZES[i]));
            PlacedFeature placed = new PlacedFeature(Holder.direct(configured), List.of(
                    CountPlacement.of(COUNTS[i]), InSquarePlacement.spread(),
                    HeightRangePlacement.uniform(VerticalAnchor.absolute(MIN_Y[i]), VerticalAnchor.absolute(MAX_Y[i])), BiomeFilter.biome()));
            event.getGeneration().addFeature(GenerationStep.Decoration.UNDERGROUND_ORES, placed);
        }
    }
}
