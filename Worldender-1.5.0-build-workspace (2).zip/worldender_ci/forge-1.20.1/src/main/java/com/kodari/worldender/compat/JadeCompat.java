package com.kodari.worldender.compat;

import com.kodari.worldender.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.entity.BlockEntity;
import snownee.jade.api.BlockAccessor;
import snownee.jade.api.IBlockComponentProvider;
import snownee.jade.api.IWailaClientRegistration;
import snownee.jade.api.IWailaCommonRegistration;
import snownee.jade.api.IWailaPlugin;
import snownee.jade.api.ITooltip;
import snownee.jade.api.IServerDataProvider;
import snownee.jade.api.WailaPlugin;
import snownee.jade.api.config.IPluginConfig;

@WailaPlugin
public final class JadeCompat implements IWailaPlugin {
    private static final ResourceLocation UID = new ResourceLocation(WorldenderMod.MOD_ID, "energy");

    @Override
    public void register(IWailaCommonRegistration registration) {
        registration.registerBlockDataProvider(EnergyInfo.INSTANCE, EnergyBlockEntity.class);
        registration.registerBlockDataProvider(EnergyInfo.INSTANCE, DeviceBlockEntity.class);
        registration.registerBlockDataProvider(EnergyInfo.INSTANCE, AlphaDeviceBlockEntity.class);
    }

    @Override
    public void registerClient(IWailaClientRegistration registration) {
        registration.registerBlockComponent(EnergyInfo.INSTANCE, EnergyBlock.class);
        registration.registerBlockComponent(EnergyInfo.INSTANCE, DeviceBlock.class);
        registration.registerBlockComponent(EnergyInfo.INSTANCE, AlphaDeviceBlock.class);
    }

    public enum EnergyInfo implements IBlockComponentProvider, IServerDataProvider<BlockAccessor> {
        INSTANCE;
        @Override public void appendTooltip(ITooltip tooltip, BlockAccessor accessor, IPluginConfig config) {
            BlockEntity be = accessor.getBlockEntity();
            CompoundTag data = accessor.getServerData();
            if (be instanceof EnergyBlockEntity || be instanceof DeviceBlockEntity || be instanceof AlphaDeviceBlockEntity) {
                long stored = data.getLong("Energy");
                long capacity = data.getLong("Capacity");
                tooltip.add(Component.literal("⚡ " + compact(stored) + " / " + compact(capacity) + " FE"));
                if (data.getBoolean("Generator")) tooltip.add(Component.literal("↯ " + compact(data.getLong("Output")) + " FE/t"));
                if (data.contains("Progress")) tooltip.add(Component.literal("◈ " + data.getInt("Progress") + " / " + data.getInt("MaxProgress") + " t"));
                if (data.getBoolean("Overclock")) tooltip.add(Component.literal("✦ OVERCLOCKED ×2"));
                if (data.contains("Countdown")) tooltip.add(Component.literal("◈ Zeta countdown: " + data.getInt("Countdown") + " t"));
                if (data.contains("Radius")) tooltip.add(Component.literal("◎ Deletion radius: " + compact(data.getLong("Radius"))));
                if (data.contains("Stabilizer")) tooltip.add(Component.literal(data.getBoolean("Stabilizer") ? "✚ STABILIZER ACTIVE" : "○ STABILIZER READY"));
            }
        }

        @Override public void appendServerData(CompoundTag data, BlockAccessor accessor) {
            BlockEntity be = accessor.getBlockEntity();
            if (be instanceof EnergyBlockEntity energy) {
                data.putLong("Energy", energy.getEnergy());
                data.putLong("Capacity", energy.getCapacity());
                if (energy.kind().isGenerator()) { data.putBoolean("Generator", true); data.putLong("Output", energy.kind().outputPerPulse * 2L); }
                if (energy.kind().isMachine()) { data.putInt("Progress", energy.getProgress()); data.putInt("MaxProgress", energy.getMachineTime()); }
                data.putBoolean("Overclock", energy.isOverclocked());
            } else if (be instanceof DeviceBlockEntity device) {
                data.putLong("Energy", device.getEnergy());
                data.putLong("Capacity", device.getCapacity());
                data.putInt("Countdown", device.getCountdown());
                data.putLong("Radius", device.getRadius());
            } else if (be instanceof AlphaDeviceBlockEntity alpha) {
                data.putLong("Energy", alpha.getEnergy());
                data.putLong("Capacity", alpha.getCapacity());
                data.putBoolean("Stabilizer", alpha.isActive());
            }
        }
        @Override public ResourceLocation getUid() { return UID; }
        @Override public int getDefaultPriority() { return -100; }

        private static String compact(long n) {
            if (n >= 1_000_000_000L) return String.format("%.2fG", n / 1_000_000_000d);
            if (n >= 1_000_000L) return String.format("%.2fM", n / 1_000_000d);
            if (n >= 1_000L) return String.format("%.1fk", n / 1_000d);
            return Long.toString(n);
        }
    }
}
