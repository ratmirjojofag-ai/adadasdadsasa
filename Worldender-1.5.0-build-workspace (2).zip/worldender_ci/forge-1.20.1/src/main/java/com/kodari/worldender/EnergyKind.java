package com.kodari.worldender;

public enum EnergyKind {
    SOLAR(250_000L, 30L), WIND(350_000L, 45L), WATER(500_000L, 60L), THERMAL(750_000L, 90L), COMBUSTION(1_000_000L, 120L), FUSION(5_000_000L, 500L), SINGULARITY(25_000_000L, 2_000L), KINETIC(5_000_000L, 1L),
    WORKBENCH(250_000L, 0L), FURNACE(400_000L, 0L), INDUCTION_FURNACE(1_000_000L, 0L), PLASMA_FURNACE(2_500_000L, 0L), PULVERIZER(750_000L, 0L), RECYCLER(750_000L, 0L), REPAIR(500_000L, 0L), SHIELD(1_500_000L, 0L), CHRONO(2_000_000L, 0L), CAPACITOR(5_000_000L, 0L), BANK(25_000_000L, 0L), QUANTUM_BANK(250_000_000L, 0L), RELAY(750_000L, 0L), TRANSFORMER(10_000_000L, 0L);
    public final long capacity;
    public final long outputPerPulse;
    EnergyKind(long capacity, long outputPerPulse) { this.capacity = capacity; this.outputPerPulse = outputPerPulse; }
    public boolean isGenerator() { return outputPerPulse > 0L; }
    public boolean isMachine() { return isFurnace() || this == PULVERIZER || this == RECYCLER || this == REPAIR; }
    public boolean isFurnace() { return this == FURNACE || this == INDUCTION_FURNACE || this == PLASMA_FURNACE; }
    public boolean isStorage() { return this == CAPACITOR || this == BANK || this == QUANTUM_BANK; }
}
