package com.kodari.worldender.compat;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.entity.BlockEntity;

import java.lang.reflect.Method;

/** Optional Create compatibility with no hard runtime dependency on Create. */
public final class CreateKineticCompat {
    private static final String KINETIC_CLASS = "com.simibubi.create.content.kinetics.base.KineticBlockEntity";
    private static volatile Class<?> cachedClass;
    private static volatile Method speedMethod;
    private CreateKineticCompat() {}

    public static long getEnergyPerPulse(ServerLevel level, BlockPos pos) {
        if (!net.minecraftforge.fml.ModList.get().isLoaded("create")) return 0L;
        double bestSpeed = 0.0;
        for (int dx = -3; dx <= 3; dx++) for (int dy = -2; dy <= 2; dy++) for (int dz = -3; dz <= 3; dz++) {
            if (dx == 0 && dy == 0 && dz == 0) continue;
            BlockEntity be = level.getBlockEntity(pos.offset(dx, dy, dz));
            if (be == null || !isKinetic(be)) continue;
            Double speed = speedOf(be);
            if (speed != null) bestSpeed = Math.max(bestSpeed, Math.abs(speed));
        }
        // The Worldender ticker consumes this value once every 10 game ticks.
        return Math.min(500_000L, Math.round(bestSpeed * 250.0));
    }

    private static boolean isKinetic(BlockEntity be) {
        try {
            if (cachedClass == null) cachedClass = Class.forName(KINETIC_CLASS);
            return cachedClass.isInstance(be);
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static Double speedOf(BlockEntity be) {
        try {
            if (speedMethod == null) {
                if (cachedClass == null) cachedClass = Class.forName(KINETIC_CLASS);
                speedMethod = cachedClass.getMethod("getSpeed");
                speedMethod.setAccessible(true);
            }
            Object value = speedMethod.invoke(be);
            return value instanceof Number n ? n.doubleValue() : null;
        } catch (Throwable ignored) {
            return null;
        }
    }
}
