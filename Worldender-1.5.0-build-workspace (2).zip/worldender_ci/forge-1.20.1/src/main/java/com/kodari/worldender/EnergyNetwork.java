package com.kodari.worldender;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;

public final class EnergyNetwork {
    private static final int MAX_NODES = 512;
    private static final int MAX_TRANSFER_TARGETS = 64;
    private EnergyNetwork() {}
    public static long push(ServerLevel world, BlockPos origin, long energy) { return energy <= 0 ? 0 : transfer(world, origin, energy, false); }
    public static long pull(ServerLevel world, BlockPos origin, long amount) { return amount <= 0 ? 0 : transfer(world, origin, amount, true); }
    private static long transfer(ServerLevel world, BlockPos origin, long amount, boolean extract) {
        ArrayDeque<BlockPos> queue = new ArrayDeque<>(); Set<BlockPos> visited = new HashSet<>(); BlockPos start = origin.immutable(); queue.add(start); visited.add(start);
        long remaining = amount; int targets = 0;
        while (!queue.isEmpty() && remaining > 0 && visited.size() <= MAX_NODES && targets < MAX_TRANSFER_TARGETS) {
            BlockPos pos = queue.removeFirst();
            if (world.getBlockEntity(pos) instanceof EnergyStorage storage && !pos.equals(start)) {
                long moved = extract ? storage.extractEnergy(remaining, false) : storage.receiveEnergy(remaining, false); remaining -= moved; if (moved > 0) targets++;
            }
            for (Direction dir : Direction.values()) {
                BlockPos next = pos.relative(dir); if (visited.contains(next)) continue; BlockState state = world.getBlockState(next);
                if (state.is(WorldenderMod.ENERGY_CABLE.get()) || state.is(WorldenderMod.ENERGY_RELAY.get()) || state.is(WorldenderMod.ENERGY_TRANSFORMER.get()) || world.getBlockEntity(next) instanceof EnergyStorage) {
                    BlockPos immutable = next.immutable(); visited.add(immutable); queue.addLast(immutable);
                }
            }
        }
        return amount - remaining;
    }
    public static long pullIntoItem(ServerLevel world, BlockPos pos, ItemStack stack, long amount) {
        if (!(stack.getItem() instanceof EnergyItem item)) return 0; long free = item.getCapacity() - item.getEnergy(stack); long request = Math.min(Math.max(0L, amount), free); if (request <= 0) return 0;
        long fromWorld = pull(world, pos, request); return fromWorld > 0 ? item.receive(stack, fromWorld) : 0;
    }
}
