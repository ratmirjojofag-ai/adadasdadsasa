package com.kodari.worldender.compat;

import com.kodari.worldender.WorldenderMod;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.registration.IRecipeRegistration;
import mezz.jei.api.registration.IRecipeCatalystRegistration;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

@JeiPlugin
public final class JEICompat implements IModPlugin {
    private static final ResourceLocation UID = new ResourceLocation(WorldenderMod.MOD_ID, "jei_plugin");
    @Override public ResourceLocation getPluginUid() { return UID; }

    @Override
    public void registerRecipes(IRecipeRegistration registration) {
        // JEI already discovers Worldender's datapack crafting recipes automatically.
        // We add useful informational lines so the energy ecosystem is searchable.
        registration.addIngredientInfo(new ItemStack(WorldenderMod.ENERGY_CELL.get()),
                mezz.jei.api.constants.VanillaTypes.ITEM_STACK,
                Component.translatable("jei.worldender.energy_cell.info"));
        registration.addIngredientInfo(new ItemStack(WorldenderMod.QUANTUM_CELL.get()),
                mezz.jei.api.constants.VanillaTypes.ITEM_STACK,
                Component.translatable("jei.worldender.quantum_cell.info"));
    }

    // Worldender crafting/processing recipes are regular datapack recipes, so JEI
    // discovers them automatically. Keeping this plugin focused on metadata avoids
    // pretending custom processing is a vanilla recipe category.
}
