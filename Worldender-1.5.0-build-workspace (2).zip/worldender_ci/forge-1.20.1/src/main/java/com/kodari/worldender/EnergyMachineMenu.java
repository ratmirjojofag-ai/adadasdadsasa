package com.kodari.worldender;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;


/** A polished, lightweight machine dashboard. Slots are backed by the actual block entity. */
public final class EnergyMachineMenu extends AbstractContainerMenu {
    public static final int MODE_ENERGY = 0;
    public static final int MODE_ZETA = 1;
    public static final int MODE_ALPHA = 2;

    private final Inventory playerInventory;
    private final BlockPos pos;
    private final int mode;
    private final Container bridge;
    private final SimpleData data;

    public EnergyMachineMenu(int containerId, Inventory inventory, FriendlyByteBuf buf) {
        this(containerId, inventory, buf.readBlockPos(), buf.readVarInt());
    }

    public EnergyMachineMenu(int containerId, Inventory inventory, BlockPos pos, int mode) {
        super(WorldenderMod.ENERGY_MENU.get(), containerId);
        this.playerInventory = inventory;
        this.pos = pos;
        this.mode = mode;
        this.data = new SimpleData();
        this.bridge = new BlockEntityContainer(inventory.player.level().getBlockEntity(pos));

        if (mode == MODE_ENERGY && bridge.getContainerSize() > 0) {
            addSlot(new Slot(bridge, 0, 108, 72) {
                @Override public boolean mayPlace(ItemStack stack) {
                    BlockEntity be = playerInventory.player.level().getBlockEntity(pos);
                    return be instanceof EnergyBlockEntity e && e.kind().isMachine() && e.getOutputStack().isEmpty();
                }
                @Override public int getMaxStackSize() { return 1; }
            });
            addSlot(new Slot(bridge, 1, 194, 72) {
                @Override public boolean mayPlace(ItemStack stack) { return false; }
                @Override public boolean mayPickup(Player player) { return !getItem().isEmpty(); }
            });
        }

        for (int row = 0; row < 3; ++row)
            for (int col = 0; col < 9; ++col)
                addSlot(new Slot(inventory, col + row * 9 + 9, 32 + col * 18, 122 + row * 18));
        for (int col = 0; col < 9; ++col)
            addSlot(new Slot(inventory, col, 32 + col * 18, 180));

        addDataSlots(data);
        refreshServerData();
    }

    public EnergyMachineMenu(int containerId, Inventory inventory, FriendlyByteBuf ignored, boolean unused) {
        this(containerId, inventory, ignored);
    }

    private void refreshServerData() {
        if (playerInventory.player.level().isClientSide) return;
        BlockEntity be = playerInventory.player.level().getBlockEntity(pos);
        long energy = 0, capacity = 0;
        int progress = 0, maxProgress = 0;
        if (be instanceof EnergyStorage e) { energy = e.getEnergy(); capacity = e.getCapacity(); }
        if (be instanceof EnergyBlockEntity e) { progress = e.getProgress(); maxProgress = e.getMachineTime(); }
        if (be instanceof DeviceBlockEntity e) { energy = e.getEnergy(); capacity = e.getCapacity(); }
        if (be instanceof AlphaDeviceBlockEntity e) { energy = e.getEnergy(); capacity = e.getCapacity(); }
        data.setLong(0, energy);
        data.setLong(2, capacity);
        data.set(4, progress);
        data.set(5, maxProgress);
    }

    @Override public void broadcastChanges() {
        refreshServerData();
        super.broadcastChanges();
    }

    public BlockPos getPos() { return pos; }
    public int getMode() { return mode; }
    public long getEnergy() { return data.getLong(0); }
    public long getCapacity() { return data.getLong(2); }
    public int getProgress() { return data.get(4); }
    public int getMachineTime() { return data.get(5); }

    @Override public ItemStack quickMoveStack(Player player, int index) {
        ItemStack copy = ItemStack.EMPTY;
        if (mode == MODE_ENERGY && index < 2) {
            Slot slot = slots.get(index);
            if (slot.hasItem()) {
                copy = slot.getItem().copy();
                if (!moveItemStackTo(copy, 2, slots.size(), true)) return ItemStack.EMPTY;
                slot.set(ItemStack.EMPTY);
                slot.onQuickCraft(copy, copy);
            }
        } else if (index >= 2) {
            ItemStack stack = slots.get(index).getItem();
            if (mode == MODE_ENERGY && !moveItemStackTo(stack, 0, 1, false)) return ItemStack.EMPTY;
            if (stack.isEmpty()) slots.get(index).set(ItemStack.EMPTY);
            else slots.get(index).setChanged();
        }
        return copy;
    }

    @Override public boolean stillValid(Player player) {
        if (player.distanceToSqr(pos.getX() + .5, pos.getY() + .5, pos.getZ() + .5) > 64.0) return false;
        BlockState state = player.level().getBlockState(pos);
        return mode == MODE_ZETA ? state.is(WorldenderMod.DEVICE.get())
             : mode == MODE_ALPHA ? state.is(WorldenderMod.ALPHA_DEVICE.get())
             : state.getBlock() instanceof EnergyBlock;
    }

    private static final class SimpleData extends net.minecraft.world.inventory.SimpleContainerData {
        SimpleData() { super(6); }
        long getLong(int base) { return ((long)get(base + 1) << 32) | (get(base) & 0xFFFFFFFFL); }
        void setLong(int base, long value) { set(base, (int)value); set(base + 1, (int)(value >>> 32)); }
    }

    private static final class BlockEntityContainer implements Container {
        private final BlockEntity entity;
        BlockEntityContainer(BlockEntity entity) { this.entity = entity; }
        private EnergyBlockEntity energy() { return entity instanceof EnergyBlockEntity e ? e : null; }
        @Override public int getContainerSize() { return energy() != null && energy().kind().isMachine() ? 2 : 0; }
        @Override public boolean isEmpty() { EnergyBlockEntity e = energy(); return e == null || (e.getInputStack().isEmpty() && e.getOutputStack().isEmpty()); }
        @Override public ItemStack getItem(int slot) { EnergyBlockEntity e = energy(); if (e == null) return ItemStack.EMPTY; return slot == 0 ? e.getInputStack() : e.getOutputStack(); }
        @Override public ItemStack removeItem(int slot, int amount) { EnergyBlockEntity e = energy(); if (e == null) return ItemStack.EMPTY; return slot == 0 ? e.removeInput(amount) : e.takeOutput(); }
        @Override public ItemStack removeItemNoUpdate(int slot) { return removeItem(slot, Integer.MAX_VALUE); }
        @Override public void setItem(int slot, ItemStack stack) {
            EnergyBlockEntity e = energy();
            if (e == null) return;
            if (slot == 0) {
                if (stack.isEmpty()) e.removeInput(64); else e.setGuiInput(stack);
            } else if (slot == 1) {
                e.setGuiOutput(stack);
            }
        }
        @Override public void setChanged() { if (entity != null) entity.setChanged(); }
        @Override public boolean stillValid(Player player) { return true; }
        @Override public void clearContent() { EnergyBlockEntity e = energy(); if (e != null) { while (!e.getInputStack().isEmpty()) e.removeInput(64); while (!e.getOutputStack().isEmpty()) e.takeOutput(); } }
    }
}
