package com.kodari.worldender.compat;

import com.kodari.worldender.EnergyBlockEntity;
import org.antarcticgardens.esl.energy.EnergyStorage;
import org.antarcticgardens.esl.transaction.SnapshotParticipant;
import org.antarcticgardens.esl.transaction.TransactionContext;

/** Bridges Worldender's internal FE store into Create New Age's ESL electrical network. */
public final class CreateNewAgeCompat {
    private CreateNewAgeCompat() {}

    public static void init() {
        EnergyStorage.registerForBlockEntity((blockEntity, direction) ->
                blockEntity instanceof EnergyBlockEntity be ? new Adapter(be) : null,
                com.kodari.worldender.WorldenderMod.ENERGY.get());
        System.out.println("[Worldender] Create New Age compatibility enabled: Worldender energy blocks can join the ESL electrical network.");
    }

    private static final class Adapter extends SnapshotParticipant<Long> implements EnergyStorage {
        private final EnergyBlockEntity be;
        Adapter(EnergyBlockEntity be) { this.be = be; }

        @Override public long insert(long maxAmount, TransactionContext txn) {
            if (!supportsInsertion() || maxAmount <= 0) return 0;
            if (txn != null) updateSnapshots(txn);
            return be.receiveEnergy(maxAmount, false);
        }

        @Override public long extract(long maxAmount, TransactionContext txn) {
            if (!supportsExtraction() || maxAmount <= 0) return 0;
            if (txn != null) updateSnapshots(txn);
            return be.extractEnergy(maxAmount, false);
        }

        @Override public long getStoredEnergy() { return be.getEnergy(); }
        @Override public long getCapacity() { return be.getCapacity(); }
        @Override public boolean supportsInsertion() { return !be.kind().isGenerator(); }
        @Override public boolean supportsExtraction() { return true; }
        @Override public Long createSnapshot() { return be.getEnergy(); }
        @Override public void restoreSnapshot(Long snapshot) {
            if (snapshot == null) return;
            long current = be.getEnergy();
            if (current > snapshot) be.extractEnergy(current - snapshot, false);
            else if (current < snapshot) be.receiveEnergy(snapshot - current, false);
        }
    }
}
