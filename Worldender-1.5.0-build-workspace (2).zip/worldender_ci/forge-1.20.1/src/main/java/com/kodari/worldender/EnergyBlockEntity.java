package com.kodari.worldender;

import com.kodari.worldender.compat.CreateKineticCompat;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.Direction;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.energy.IEnergyStorage;

public final class EnergyBlockEntity extends BlockEntity implements EnergyStorage {
    private long energy;
    private int progress;
    private int overclockTicks;
    private ItemStack input = ItemStack.EMPTY;
    private ItemStack output = ItemStack.EMPTY;
    private long pulse;
    private final LazyOptional<IEnergyStorage> forgeEnergy = LazyOptional.of(() -> new IEnergyStorage() {
        @Override public int receiveEnergy(int maxReceive, boolean simulate) {
            if (!canReceive() || maxReceive <= 0) return 0;
            return (int) Math.min(Integer.MAX_VALUE, EnergyBlockEntity.this.receiveEnergy(maxReceive, simulate));
        }
        @Override public int extractEnergy(int maxExtract, boolean simulate) {
            if (!canExtract() || maxExtract <= 0) return 0;
            return (int) Math.min(Integer.MAX_VALUE, EnergyBlockEntity.this.extractEnergy(maxExtract, simulate));
        }
        @Override public int getEnergyStored() { return (int) Math.min(Integer.MAX_VALUE, EnergyBlockEntity.this.getEnergy()); }
        @Override public int getMaxEnergyStored() { return (int) Math.min(Integer.MAX_VALUE, EnergyBlockEntity.this.getCapacity()); }
        @Override public boolean canExtract() { return true; }
        @Override public boolean canReceive() { return !EnergyBlockEntity.this.kind().isGenerator(); }
    });

    public EnergyBlockEntity(BlockPos pos, BlockState state) { super(WorldenderMod.ENERGY.get(), pos, state); }
    public EnergyKind kind() { return ((EnergyBlock) getBlockState().getBlock()).kind(); }
    @Override public long getEnergy() { return energy; }
    @Override public <T> LazyOptional<T> getCapability(Capability<T> capability, Direction side) {
        if (capability == ForgeCapabilities.ENERGY) return forgeEnergy.cast();
        return super.getCapability(capability, side);
    }
    @Override public void setRemoved() {
        forgeEnergy.invalidate();
        super.setRemoved();
    }
    @Override public long getCapacity() { return kind().capacity; }
    @Override public long receiveEnergy(long amount, boolean simulate) {
        long accepted = Math.min(Math.max(0L, amount), Math.max(0L, getCapacity() - energy));
        if (!simulate && accepted > 0L) { energy += accepted; setChanged(); }
        return accepted;
    }
    @Override public long extractEnergy(long amount, boolean simulate) {
        long taken = Math.min(Math.max(0L, amount), energy);
        if (!simulate && taken > 0L) { energy -= taken; setChanged(); }
        return taken;
    }
    public boolean enableOverclock(int ticks) { if (overclockTicks > 0) return false; overclockTicks = ticks; setChanged(); return true; }
    public int getInputCount() { return input.isEmpty() ? 0 : input.getCount(); }
    public ItemStack getInputStack() { return input.copy(); }
    public ItemStack getOutputStack() { return output.copy(); }
    public int getProgress() { return progress; }
    public int getMachineTime() { return machineTime(); }
    public boolean isOverclocked() { return overclockTicks > 0; }
    public boolean insertInput(ItemStack stack) {
        if (!input.isEmpty() || stack.isEmpty() || !isValidMachineInput(stack)) return false;
        input = stack.copy(); input.setCount(1); setChanged(); return true;
    }
    public ItemStack takeOutput() { if (output.isEmpty()) return ItemStack.EMPTY; ItemStack result = output.copy(); output = ItemStack.EMPTY; setChanged(); return result; }
    public void setGuiOutput(ItemStack stack) { output = stack == null ? ItemStack.EMPTY : stack.copy(); setChanged(); }
    public ItemStack removeInput(int amount) {
        if (amount <= 0 || input.isEmpty()) return ItemStack.EMPTY;
        int taken = Math.min(amount, input.getCount());
        ItemStack result = input.split(taken);
        if (input.isEmpty()) input = ItemStack.EMPTY;
        setChanged();
        return result;
    }
    public boolean setGuiInput(ItemStack stack) {
        if (kind().isMachine() && output.isEmpty() && input.isEmpty() && !stack.isEmpty() && isValidMachineInput(stack)) {
            input = stack.copy();
            input.setCount(1);
            setChanged();
            return true;
        }
        return false;
    }

    private boolean isValidMachineInput(ItemStack stack) {
        EnergyKind k = kind();
        if (k.isFurnace()) return isSmeltInput(stack);
        if (k == EnergyKind.PULVERIZER) return isOreBlock(stack) || isSmeltInput(stack) || stack.is(Items.IRON_INGOT) || stack.is(Items.COPPER_INGOT);
        if (k == EnergyKind.RECYCLER) return stack.is(Items.COBBLESTONE) || stack.is(Items.GRAVEL) || stack.is(Items.NETHERRACK) || stack.is(Items.ROTTEN_FLESH) || stack.is(Items.KELP);
        return false;
    }
    private boolean isSmeltInput(ItemStack stack) {
        return stack.is(Items.RAW_IRON) || stack.is(Items.RAW_GOLD) || stack.is(Items.RAW_COPPER) || stack.is(Items.IRON_ORE) || stack.is(Items.GOLD_ORE) || stack.is(Items.COPPER_ORE)
                || stack.is(WorldenderMod.RAW_ORES[0].get()) || stack.is(WorldenderMod.RAW_ORES[1].get()) || stack.is(WorldenderMod.RAW_ORES[2].get()) || stack.is(WorldenderMod.RAW_ORES[3].get())
                || stack.is(WorldenderMod.RAW_ORES[4].get()) || stack.is(WorldenderMod.RAW_ORES[5].get()) || stack.is(WorldenderMod.RAW_ORES[6].get()) || stack.is(WorldenderMod.RAW_ORES[7].get());
    }
    private boolean isOreBlock(ItemStack stack) {
        for (var block : WorldenderMod.ORE_BLOCKS) if (stack.is(block.get().asItem())) return true;
        return stack.is(Items.IRON_ORE) || stack.is(Items.GOLD_ORE) || stack.is(Items.COPPER_ORE);
    }
    private ItemStack furnaceResult(ItemStack in) {
        int multiplier = kind() == EnergyKind.PLASMA_FURNACE ? 2 : 1;
        if (in.is(Items.RAW_IRON) || in.is(Items.IRON_ORE)) return new ItemStack(Items.IRON_INGOT, multiplier);
        if (in.is(Items.RAW_GOLD) || in.is(Items.GOLD_ORE)) return new ItemStack(Items.GOLD_INGOT, multiplier);
        if (in.is(Items.RAW_COPPER) || in.is(Items.COPPER_ORE)) return new ItemStack(Items.COPPER_INGOT, multiplier);
        for (int i = 0; i < 8; i++) if (in.is(WorldenderMod.RAW_ORES[i].get())) return new ItemStack(WorldenderMod.INGOTS[i].get(), multiplier);
        return ItemStack.EMPTY;
    }
    private ItemStack pulverizerResult(ItemStack in) {
        if (in.is(Items.IRON_ORE)) return new ItemStack(Items.RAW_IRON, 2);
        if (in.is(Items.GOLD_ORE)) return new ItemStack(Items.RAW_GOLD, 2);
        if (in.is(Items.COPPER_ORE)) return new ItemStack(Items.RAW_COPPER, 2);
        for (int i = 0; i < 8; i++) if (in.is(WorldenderMod.ORE_BLOCKS[i].get().asItem())) return new ItemStack(WorldenderMod.RAW_ORES[i].get(), 2);
        if (in.is(Items.IRON_INGOT)) return new ItemStack(Items.IRON_NUGGET, 12);
        if (in.is(Items.COPPER_INGOT)) return new ItemStack(Items.COPPER_NUGGET, 12);
        return ItemStack.EMPTY;
    }
    private ItemStack recycleResult(ItemStack in) {
        if (in.is(Items.COBBLESTONE)) return new ItemStack(Items.GRAVEL);
        if (in.is(Items.GRAVEL)) return new ItemStack(Items.SAND);
        if (in.is(Items.NETHERRACK)) return new ItemStack(Items.NETHER_BRICK);
        if (in.is(Items.ROTTEN_FLESH)) return new ItemStack(Items.BONE_MEAL, 2);
        if (in.is(Items.KELP)) return new ItemStack(Items.DRIED_KELP);
        return ItemStack.EMPTY;
    }
    private long machineCost() {
        return switch (kind()) { case FURNACE -> 2_500L; case INDUCTION_FURNACE -> 9_000L; case PLASMA_FURNACE -> 25_000L; case PULVERIZER -> 5_000L; case RECYCLER -> 7_000L; default -> 0L; };
    }
    private int machineTime() {
        return switch (kind()) { case FURNACE -> 80; case INDUCTION_FURNACE -> 50; case PLASMA_FURNACE -> 30; case PULVERIZER -> 40; case RECYCLER -> 35; default -> 80; };
    }
    private long generate(ServerLevel world, BlockPos pos) {
        return switch (kind()) {
            case SOLAR -> world.isDay() && world.canSeeSky(pos.above()) ? 40L : 0L;
            case WIND -> 45L + Math.max(0, pos.getY() - 64) / 2L;
            case WATER -> (world.getFluidState(pos.north()).isSource() || world.getFluidState(pos.south()).isSource() || world.getFluidState(pos.east()).isSource() || world.getFluidState(pos.west()).isSource()) ? 60L : 0L;
            case THERMAL -> world.getBlockState(pos.below()).is(Blocks.LAVA) ? 100L : 0L;
            case COMBUSTION -> world.getBlockState(pos.below()).is(Blocks.COAL_BLOCK) ? 140L : 0L;
            case FUSION -> 520L + (world.getGameTime() % 200L == 0L ? 180L : 0L);
            case SINGULARITY -> 2_000L + ((world.getGameTime() / 24_000L) % 8L) * 100L;
            case KINETIC -> CreateKineticCompat.getEnergyPerPulse(world, pos);
            default -> 0L;
        };
    }
    public static void tick(Level level, BlockPos pos, BlockState state, EnergyBlockEntity entity) {
        if (!(level instanceof ServerLevel server)) return;
        entity.pulse++;
        EnergyKind kind = entity.kind();
        int speedMultiplier = entity.overclockTicks > 0 ? 2 : 1;
        if (entity.overclockTicks > 0) entity.overclockTicks--;

        if (kind.isGenerator() && entity.pulse % 10L == 0L) {
            long produced = entity.generate(server, pos) * speedMultiplier;
            long free = entity.getCapacity() - entity.energy;
            entity.energy = Math.min(entity.getCapacity(), entity.energy + Math.min(free, produced));
            long transferLimit = kind == EnergyKind.SINGULARITY ? 50_000L : 10_000L * speedMultiplier;
            long pushed = EnergyNetwork.push(server, pos, Math.min(transferLimit, Math.max(0L, entity.energy - 500L)));
            entity.energy = Math.max(0L, entity.energy - pushed);
            entity.setChanged();
        }
        if (kind.isMachine() && kind != EnergyKind.REPAIR && !entity.input.isEmpty() && entity.output.isEmpty()) {
            long cost = entity.machineCost();
            if (entity.energy < cost) entity.energy += EnergyNetwork.pull(server, pos, cost - entity.energy);
            if (entity.energy >= cost) {
                entity.energy -= cost; entity.progress += speedMultiplier;
                if (entity.progress >= entity.machineTime()) {
                    ItemStack result = switch (kind) { case PULVERIZER -> entity.pulverizerResult(entity.input); case RECYCLER -> entity.recycleResult(entity.input); default -> entity.furnaceResult(entity.input); };
                    entity.input = ItemStack.EMPTY; entity.progress = 0; if (!result.isEmpty()) entity.output = result;
                }
                entity.setChanged();
            }
        }
        if (kind == EnergyKind.SHIELD && entity.energy >= 20L) {
            for (Player player : server.players()) if (player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 24 * 24) player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 45, 0, true, false));
            entity.energy -= 20L; entity.setChanged();
        }
        if (kind == EnergyKind.CHRONO) {
            boolean charged = entity.energy >= 1_000L;
            DeletionEngine.updateChronoAnchor(server, pos, charged);
            if (charged && entity.pulse % 20L == 0L) { entity.energy -= 25L; entity.setChanged(); }
        }
    }
    public int repairNearby(Player player) {
        if (kind() != EnergyKind.REPAIR || energy < 6_000L) return 0;
        for (int slot = 0; slot < player.getInventory().getContainerSize(); slot++) {
            ItemStack stack = player.getInventory().getItem(slot);
            if (stack.isDamageableItem() && stack.getDamageValue() > 0) {
                int repaired = Math.min(50, stack.getDamageValue()); stack.setDamageValue(stack.getDamageValue() - repaired); energy -= 6_000L; setChanged(); return repaired;
            }
        }
        return 0;
    }
    @Override protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag); tag.putLong("Energy", energy); tag.putInt("Progress", progress); tag.putInt("Overclock", overclockTicks);
        if (!input.isEmpty()) tag.put("Input", input.save(new CompoundTag())); if (!output.isEmpty()) tag.put("Output", output.save(new CompoundTag()));
    }
    @Override public void load(CompoundTag tag) {
        super.load(tag); energy = Math.max(0L, tag.getLong("Energy")); progress = Math.max(0, tag.getInt("Progress")); overclockTicks = Math.max(0, tag.getInt("Overclock"));
        input = tag.contains("Input") ? ItemStack.of(tag.getCompound("Input")) : ItemStack.EMPTY; output = tag.contains("Output") ? ItemStack.of(tag.getCompound("Output")) : ItemStack.EMPTY;
    }
}
