package com.kodari.worldender;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.server.level.ServerLevel;

import java.util.Collections;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/** Origin-centered autonomous deletion front used by StartDeletingWorld and the Zeta/Alpha devices. */
public final class DeletionEngine {
    private static final long TICKS_PER_REAL_MINUTE = 1_200L;
    private static final int MAX_RADIUS = 30_000_000;
    private static final int CHUNKS_PER_TICK = 6;
    private static final int CHRONO_RADIUS = 32;
    private static final int ALPHA_RADIUS = 64;
    private static final Map<ServerLevel, State> STATES = Collections.synchronizedMap(new IdentityHashMap<>());
    private DeletionEngine() {}
    public static void initializeWorld(ServerLevel world) { STATES.computeIfAbsent(world, ignored -> new State()); }
    public static void unloadWorld(ServerLevel world) { STATES.remove(world); }
    public static void tick(ServerLevel world) {
        if (world.dimension() != Level.OVERWORLD) return;
        State state = STATES.computeIfAbsent(world, ignored -> new State());
        if (!world.getGameRules().getRule(WorldenderMod.START_DELETING_WORLD).get()) return;
        if (!state.announced) { world.players().forEach(p -> p.displayClientMessage(Component.literal("START_DELETING_WORLD: autonomous Zeta wave started at 0 0 0."), true)); state.announced = true; }
        int radius = getRadius(world), speed = getSpeed(world);
        if (state.lastSpeed != speed) { state.lastSpeed = speed; world.players().forEach(p -> p.displayClientMessage(Component.literal("Deletion front: " + speed + " blocks/min (survival day " + getDays(world) + ")."), true)); }
        if (radius <= 0) return;
        processLoadedChunks(world, state, radius, CHUNKS_PER_TICK); pruneChrono(world, state);
    }
    public static int getDays(ServerLevel world) { return (int)Math.max(0L, world.getGameTime() / 24_000L); }
    public static int getSpeed(ServerLevel world) { int day = getDays(world); if (day >= 35) return 60; if (day >= 20) return 45; if (day >= 5) return 30; return 10; }
    public static int getRadius(ServerLevel world) {
        State state = STATES.computeIfAbsent(world, ignored -> new State()); if (state.radiusOverride >= 0) return state.radiusOverride;
        long minutes = world.getGameTime() / TICKS_PER_REAL_MINUTE, day5 = 5L * 20L, day20 = 20L * 20L, day35 = 35L * 20L, radius;
        if (minutes <= day5) radius = minutes * 10L;
        else if (minutes <= day20) radius = day5 * 10L + (minutes - day5) * 30L;
        else if (minutes <= day35) radius = day5 * 10L + (day20 - day5) * 30L + (minutes - day20) * 45L;
        else radius = day5 * 10L + (day20 - day5) * 30L + (day35 - day20) * 45L + (minutes - day35) * 60L;
        return (int)Math.min(MAX_RADIUS, radius);
    }
    public static void setRadiusOverride(ServerLevel world, int radius) { STATES.computeIfAbsent(world, ignored -> new State()).radiusOverride = Math.max(0, Math.min(MAX_RADIUS, radius)); }
    public static void clearRadiusOverride(ServerLevel world) { STATES.computeIfAbsent(world, ignored -> new State()).radiusOverride = -1; }
    public static void onChunkLoad(ServerLevel world, LevelChunk chunk) {
        State state = STATES.computeIfAbsent(world, ignored -> new State()); state.loadedChunks.add(key(chunk.getPos().x, chunk.getPos().z));
        if (world.dimension() != Level.OVERWORLD || !world.getGameRules().getRule(WorldenderMod.START_DELETING_WORLD).get()) return;
        int radius = getRadius(world); if (radius > 0 && intersectsCircle(chunk, radius)) eraseChunkForCircle(world, chunk, radius, state);
    }
    public static void onChunkUnload(ServerLevel world, LevelChunk chunk) {
        State state = STATES.get(world); if (state == null) return; long key = key(chunk.getPos().x, chunk.getPos().z); state.loadedChunks.remove(key); state.erasedChunks.remove(key);
        int cx = chunk.getPos().x, cz = chunk.getPos().z;
        state.chronoAnchors.removeIf(packed -> { BlockPos pos = BlockPos.of(packed); return (pos.getX() >> 4) == cx && (pos.getZ() >> 4) == cz; });
        state.alphaStabilizers.removeIf(packed -> { BlockPos pos = BlockPos.of(packed); return (pos.getX() >> 4) == cx && (pos.getZ() >> 4) == cz; });
    }
    private static void processLoadedChunks(ServerLevel world, State state, int radius, int budget) {
        if (state.loadedChunks.isEmpty()) return; Object[] loaded = state.loadedChunks.toArray(); int processed = 0;
        for (int i = 0; i < loaded.length && processed < budget; i++) {
            int index = Math.floorMod(state.chunkCursor + i, loaded.length); long k = (Long)loaded[index]; int cx = (int)(k >> 32), cz = (int)k; LevelChunk chunk = world.getChunk(cx, cz);
            if (intersectsCircle(chunk, radius)) eraseChunkForCircle(world, chunk, radius, state); processed++;
        }
        state.chunkCursor = Math.floorMod(state.chunkCursor + Math.max(1, processed), Math.max(1, loaded.length));
    }
    private static boolean intersectsCircle(LevelChunk chunk, int radius) {
        int minX = chunk.getPos().getMinBlockX(), maxX = minX + 15, minZ = chunk.getPos().getMinBlockZ(), maxZ = minZ + 15;
        long dx = minX > 0 ? minX : maxX < 0 ? -maxX : 0, dz = minZ > 0 ? minZ : maxZ < 0 ? -maxZ : 0; return dx*dx + dz*dz <= (long)radius*radius;
    }
    private static boolean fullyInsideCircle(LevelChunk chunk, int radius) {
        int minX = chunk.getPos().getMinBlockX(), maxX = minX + 15, minZ = chunk.getPos().getMinBlockZ(), maxZ = minZ + 15;
        long a = (long)minX*minX + (long)minZ*minZ, b = (long)minX*minX + (long)maxZ*maxZ, c = (long)maxX*maxX + (long)minZ*minZ, d = (long)maxX*maxX + (long)maxZ*maxZ;
        return Math.max(Math.max(a,b), Math.max(c,d)) <= (long)radius*radius;
    }
    private static void eraseChunkForCircle(ServerLevel world, LevelChunk chunk, int radius, State state) {
        long key = key(chunk.getPos().x, chunk.getPos().z); if (state.erasedChunks.contains(key)) return;
        if (isProtected(world, chunk.getPos().getMinBlockX()+8, chunk.getPos().getMinBlockZ()+8, state)) return;
        if (fullyInsideCircle(chunk, radius)) eraseChunk(world, chunk); else {
            int minX = chunk.getPos().getMinBlockX(), minZ = chunk.getPos().getMinBlockZ(); long r2 = (long)radius*radius;
            for (int x=minX; x<minX+16; x++) for (int z=minZ; z<minZ+16; z++) if ((long)x*x+(long)z*z<=r2 && !isProtected(world,x,z,state)) eraseColumn(world,x,z);
        }
        state.erasedChunks.add(key);
    }
    public static void eraseLoadedFront(ServerLevel world, int radius, int ignoredColumns) { if (radius > 0) processLoadedChunks(world, STATES.computeIfAbsent(world, ignored -> new State()), radius, CHUNKS_PER_TICK); }
    private static void eraseColumn(ServerLevel world, int x, int z) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos(x, world.getMinBuildHeight(), z);
        for (int y=world.getMinBuildHeight(); y<world.getMaxBuildHeight(); y++) { pos.setY(y); if (!world.getBlockState(pos).isAir()) world.setBlock(pos, Blocks.AIR.defaultBlockState(), 3); }
    }
    private static void eraseChunk(ServerLevel world, LevelChunk chunk) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos(); int minX=chunk.getPos().getMinBlockX(), minZ=chunk.getPos().getMinBlockZ();
        for (int x=minX; x<minX+16; x++) for (int z=minZ; z<minZ+16; z++) { pos.set(x, world.getMinBuildHeight(), z); for (int y=world.getMinBuildHeight(); y<world.getMaxBuildHeight(); y++) { pos.setY(y); if (!world.getBlockState(pos).isAir()) world.setBlock(pos, Blocks.AIR.defaultBlockState(), 3); } }
    }
    public static void updateChronoAnchor(ServerLevel world, BlockPos pos, boolean active) { State state=STATES.computeIfAbsent(world, ignored->new State()); if(active)state.chronoAnchors.add(pos.asLong()); else state.chronoAnchors.remove(pos.asLong()); }
    public static void updateAlphaStabilizer(ServerLevel world, BlockPos pos, boolean active) { State state=STATES.computeIfAbsent(world, ignored->new State()); if(active)state.alphaStabilizers.add(pos.asLong()); else state.alphaStabilizers.remove(pos.asLong()); }
    private static boolean isProtected(ServerLevel world,int x,int z,State state) {
        Iterator<Long> chrono=state.chronoAnchors.iterator(); while(chrono.hasNext()){ BlockPos pos=BlockPos.of(chrono.next()); long dx=(long)x-pos.getX(), dz=(long)z-pos.getZ(); if(dx*dx+dz*dz <= (long)CHRONO_RADIUS*CHRONO_RADIUS && world.getBlockEntity(pos) instanceof EnergyBlockEntity be && be.getEnergy()>0 && world.getBlockState(pos).is(WorldenderMod.CHRONO_ANCHOR.get())) return true; if(!(world.getBlockEntity(pos) instanceof EnergyBlockEntity)) chrono.remove(); }
        for(Long packed:state.alphaStabilizers){ BlockPos pos=BlockPos.of(packed); long dx=(long)x-pos.getX(), dz=(long)z-pos.getZ(); if(dx*dx+dz*dz <= (long)ALPHA_RADIUS*ALPHA_RADIUS)return true; }
        return false;
    }
    private static void pruneChrono(ServerLevel world, State state){ if(world.getGameTime()%100!=0)return; Iterator<Long> it=state.chronoAnchors.iterator(); while(it.hasNext()) if(!(world.getBlockEntity(BlockPos.of(it.next())) instanceof EnergyBlockEntity)) it.remove(); }
    private static long key(int x,int z){ return ((long)x << 32) ^ (z & 0xffffffffL); }
    private static final class State { final Set<Long> loadedChunks=new HashSet<>(), erasedChunks=new HashSet<>(), chronoAnchors=new HashSet<>(), alphaStabilizers=new HashSet<>(); int chunkCursor, radiusOverride=-1,lastSpeed=-1; boolean announced; }
}
