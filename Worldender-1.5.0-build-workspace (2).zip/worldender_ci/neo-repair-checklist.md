# NeoForge 1.21.1 repair checklist

The current source still contains Forge-only imports/API usage in multiple classes. Replace these before the first successful build:

- `net.minecraftforge.*` imports -> NeoForge equivalents (`net.neoforged.*`) where applicable.
- Forge registry `RegistryObject` -> NeoForge `DeferredHolder`/`DeferredItem` patterns.
- `IForgeMenuType` / `NetworkHooks` -> NeoForge menu registration and open-screen flow.
- Forge Energy capability (`ForgeCapabilities`, `IEnergyStorage`, `LazyOptional`) -> NeoForge 1.21.1 energy capability system.
- `BiomeLoadingEvent` -> modern NeoForge biome modification/worldgen hooks.
- 1.21.1 holder-based worldgen registration.
- JEI 19 registration names/signatures.
- Jade 15 provider registration/signatures.
- Create 6 / Create New Age 1.21.1 APIs.
- Add Create Aeronautics compat behind a runtime mod-presence check; do not hard-depend on it for the base NeoForge build.
