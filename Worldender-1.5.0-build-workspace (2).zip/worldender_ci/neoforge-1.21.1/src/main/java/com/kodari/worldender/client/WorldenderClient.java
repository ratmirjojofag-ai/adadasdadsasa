package com.kodari.worldender.client;

import com.kodari.worldender.EnergyMachineMenu;
import com.kodari.worldender.WorldenderMod;
import net.minecraft.client.gui.screens.MenuScreens;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = WorldenderMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class WorldenderClient {
    private WorldenderClient() {}

    @SubscribeEvent
    public static void setup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> MenuScreens.register(WorldenderMod.ENERGY_MENU.get(), EnergyMachineScreen::new));
    }
}
