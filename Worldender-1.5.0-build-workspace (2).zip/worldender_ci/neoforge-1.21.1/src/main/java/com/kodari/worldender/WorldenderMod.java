package com.kodari.worldender;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.GameRules;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.TickEvent;
import net.neoforged.neoforge.event.level.ChunkEvent;
import net.neoforged.neoforge.event.level.LevelEvent;
import net.neoforged.neoforge.event.world.BiomeLoadingEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

@Mod(WorldenderMod.MOD_ID)
public final class WorldenderMod {
    public static final String MOD_ID = "worldender";

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MOD_ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MOD_ID);
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(ForgeRegistries.MENU_TYPES, MOD_ID);

    /** Enables the autonomous origin-centered deletion wave without placing a Zeta Device. */
    public static final GameRules.Key<GameRules.BooleanValue> START_DELETING_WORLD =
            GameRules.register("StartDeletingWorld", GameRules.Category.MISC, GameRules.BooleanValue.create(false));

    public static final RegistryObject<Block> DEVICE = registerBlock("device", () -> new DeviceBlock(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).strength(10.0f)));
    public static final RegistryObject<Block> ALPHA_DEVICE = registerBlock("alpha_device", () -> new AlphaDeviceBlock(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).strength(10.0f)));

    public static final RegistryObject<Block> SOLAR_PANEL = registerBlock("solar_panel", () -> new EnergyBlock(EnergyKind.SOLAR, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> WIND_TURBINE = registerBlock("wind_turbine", () -> new EnergyBlock(EnergyKind.WIND, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> WATER_TURBINE = registerBlock("water_turbine", () -> new EnergyBlock(EnergyKind.WATER, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> THERMAL_GENERATOR = registerBlock("thermal_generator", () -> new EnergyBlock(EnergyKind.THERMAL, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> COMBUSTION_GENERATOR = registerBlock("combustion_generator", () -> new EnergyBlock(EnergyKind.COMBUSTION, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> FUSION_REACTOR = registerBlock("fusion_reactor", () -> new EnergyBlock(EnergyKind.FUSION, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> SINGULARITY_REACTOR = registerBlock("singularity_reactor", () -> new EnergyBlock(EnergyKind.SINGULARITY, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));

    public static final RegistryObject<Block> ENERGY_CELL_WORKBENCH = registerBlock("energy_cell_workbench", () -> new EnergyBlock(EnergyKind.WORKBENCH, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> ENERGY_FURNACE = registerBlock("energy_furnace", () -> new EnergyBlock(EnergyKind.FURNACE, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> INDUCTION_FURNACE = registerBlock("induction_furnace", () -> new EnergyBlock(EnergyKind.INDUCTION_FURNACE, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> PLASMA_FURNACE = registerBlock("plasma_furnace", () -> new EnergyBlock(EnergyKind.PLASMA_FURNACE, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> ORE_PULVERIZER = registerBlock("ore_pulverizer", () -> new EnergyBlock(EnergyKind.PULVERIZER, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> MATTER_RECYCLER = registerBlock("matter_recycler", () -> new EnergyBlock(EnergyKind.RECYCLER, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> REPAIR_STATION = registerBlock("repair_station", () -> new EnergyBlock(EnergyKind.REPAIR, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> SHIELD_GENERATOR = registerBlock("shield_generator", () -> new EnergyBlock(EnergyKind.SHIELD, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> CHRONO_ANCHOR = registerBlock("chrono_anchor", () -> new EnergyBlock(EnergyKind.CHRONO, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));

    public static final RegistryObject<Block> ENERGY_CAPACITOR = registerBlock("energy_capacitor", () -> new EnergyBlock(EnergyKind.CAPACITOR, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> ENERGY_BANK = registerBlock("energy_bank", () -> new EnergyBlock(EnergyKind.BANK, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> QUANTUM_ENERGY_BANK = registerBlock("quantum_energy_bank", () -> new EnergyBlock(EnergyKind.QUANTUM_BANK, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> ENERGY_RELAY = registerBlock("energy_relay", () -> new EnergyBlock(EnergyKind.RELAY, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> ENERGY_TRANSFORMER = registerBlock("energy_transformer", () -> new EnergyBlock(EnergyKind.TRANSFORMER, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));
    public static final RegistryObject<Block> ENERGY_CABLE = registerBlock("energy_cable", () -> new EnergyBlock(EnergyKind.RELAY, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).strength(2.0f)));
    public static final RegistryObject<Block> KINETIC_DYNAMO = registerBlock("kinetic_dynamo", () -> new EnergyBlock(EnergyKind.KINETIC, BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).strength(5.0f)));

    public static final String[] ORE_NAMES = {"cobalt_ore", "titanium_ore", "uranium_ore", "iridium_ore", "osmium_ore", "lithium_ore", "thorium_ore", "aetherite_ore"};
    private static final String[] MATERIAL_NAMES = {"cobalt", "titanium", "uranium", "iridium", "osmium", "lithium", "thorium", "aetherite"};
    public static final RegistryObject<Block>[] ORE_BLOCKS = new RegistryObject[ORE_NAMES.length];
    public static final RegistryObject<Item>[] RAW_ORES = new RegistryObject[ORE_NAMES.length];
    public static final RegistryObject<Item>[] INGOTS = new RegistryObject[ORE_NAMES.length];

    public static final RegistryObject<Item> ENERGY_CELL = registerItem("energy_cell", () -> new EnergyItem(100_000L, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> HIGH_CAPACITY_CELL = registerItem("high_capacity_cell", () -> new EnergyItem(1_000_000L, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> QUANTUM_CELL = registerItem("quantum_cell", () -> new EnergyItem(10_000_000L, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> SINGULARITY_CELL = registerItem("singularity_cell", () -> new EnergyItem(100_000_000L, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> ENERGY_CORE = registerItem("energy_core", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> SUPERCONDUCTOR = registerItem("superconductor", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> OVERCLOCK_MODULE = registerItem("overclock_module", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> WAVE_SHARD = registerItem("wave_shard", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> TIDAL_CORE = registerItem("tidal_core", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> WORLD_SCANNER = registerItem("world_scanner", () -> new ScannerItem(new Item.Properties().stacksTo(1).durability(64)));
    public static final RegistryObject<Item> ENERGY_MAGNET = registerItem("energy_magnet", () -> new EnergyMagnetItem(new Item.Properties().stacksTo(1).durability(512)));

    public static final RegistryObject<BlockEntityType<EnergyBlockEntity>> ENERGY = BLOCK_ENTITIES.register("energy", () ->
            BlockEntityType.Builder.of(EnergyBlockEntity::new,
                    SOLAR_PANEL.get(), WIND_TURBINE.get(), WATER_TURBINE.get(), THERMAL_GENERATOR.get(), COMBUSTION_GENERATOR.get(),
                    FUSION_REACTOR.get(), SINGULARITY_REACTOR.get(), ENERGY_CELL_WORKBENCH.get(), ENERGY_FURNACE.get(),
                    INDUCTION_FURNACE.get(), PLASMA_FURNACE.get(), ORE_PULVERIZER.get(), MATTER_RECYCLER.get(),
                    REPAIR_STATION.get(), SHIELD_GENERATOR.get(), CHRONO_ANCHOR.get(), ENERGY_CAPACITOR.get(),
                    ENERGY_BANK.get(), QUANTUM_ENERGY_BANK.get(), ENERGY_RELAY.get(), ENERGY_TRANSFORMER.get(), ENERGY_CABLE.get(), KINETIC_DYNAMO.get()).build(null));

    public static final RegistryObject<BlockEntityType<DeviceBlockEntity>> DEVICE_ENTITY = BLOCK_ENTITIES.register("device", () ->
            BlockEntityType.Builder.of(DeviceBlockEntity::new, DEVICE.get()).build(null));

    public static final RegistryObject<BlockEntityType<AlphaDeviceBlockEntity>> ALPHA_ENTITY = BLOCK_ENTITIES.register("alpha", () ->
            BlockEntityType.Builder.of(AlphaDeviceBlockEntity::new, ALPHA_DEVICE.get()).build(null));

    public static final RegistryObject<MenuType<EnergyMachineMenu>> ENERGY_MENU = MENUS.register("energy_machine", () ->
            IForgeMenuType.create(EnergyMachineMenu::new));

    static {
        for (int i = 0; i < ORE_NAMES.length; i++) {
            final String ore = ORE_NAMES[i];
            final String material = MATERIAL_NAMES[i];
            ORE_BLOCKS[i] = registerBlock(ore, () -> new Block(BlockBehaviour.Properties.copy(Blocks.IRON_ORE).strength(4.5f).requiresCorrectToolForDrops()));
            RAW_ORES[i] = registerItem("raw_" + material, () -> new Item(new Item.Properties()));
            INGOTS[i] = registerItem(material + "_ingot", () -> new Item(new Item.Properties()));
        }
    }

    private static RegistryObject<Block> registerBlock(String name, Supplier<? extends Block> supplier) {
        RegistryObject<Block> block = BLOCKS.register(name, supplier);
        ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        return block;
    }

    private static RegistryObject<Item> registerItem(String name, Supplier<? extends Item> supplier) {
        return ITEMS.register(name, supplier);
    }

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MOD_ID, path);
    }

    public WorldenderMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        BLOCK_ENTITIES.register(modBus);
        MENUS.register(modBus);
        modBus.addListener(WorldenderMod::addCreative);
        MinecraftForge.EVENT_BUS.register(new ForgeEvents());
        if (net.neoforged.fml.ModList.get().isLoaded("create_new_age")) {
            try {
                com.kodari.worldender.compat.CreateNewAgeCompat.init();
            } catch (Throwable t) {
                System.err.println("[Worldender] Create New Age compatibility failed: " + t.getMessage());
            }
        }
    }


    public static void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            List<RegistryObject<Item>> items = List.of(ENERGY_CELL, HIGH_CAPACITY_CELL, QUANTUM_CELL, SINGULARITY_CELL,
                    ENERGY_CORE, SUPERCONDUCTOR, OVERCLOCK_MODULE, WAVE_SHARD, TIDAL_CORE, WORLD_SCANNER, ENERGY_MAGNET);
            items.forEach(ro -> event.accept(ro.get()));
            for (RegistryObject<Item> ro : RAW_ORES) event.accept(ro.get());
            for (RegistryObject<Item> ro : INGOTS) event.accept(ro.get());
        }
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            List<RegistryObject<Block>> blocks = new ArrayList<>(List.of(DEVICE, ALPHA_DEVICE, SOLAR_PANEL, WIND_TURBINE, WATER_TURBINE, THERMAL_GENERATOR,
                    COMBUSTION_GENERATOR, FUSION_REACTOR, SINGULARITY_REACTOR, ENERGY_CELL_WORKBENCH, ENERGY_FURNACE, INDUCTION_FURNACE,
                    PLASMA_FURNACE, ORE_PULVERIZER, MATTER_RECYCLER, REPAIR_STATION, SHIELD_GENERATOR, CHRONO_ANCHOR, ENERGY_CAPACITOR,
                    ENERGY_BANK, QUANTUM_ENERGY_BANK, ENERGY_RELAY, ENERGY_TRANSFORMER, ENERGY_CABLE, KINETIC_DYNAMO));
            for (RegistryObject<Block> ro : ORE_BLOCKS) blocks.add(ro);
            blocks.forEach(ro -> event.accept(ro.get()));
        }
    }

    public static final class ForgeEvents {
        private ForgeEvents() {}

        @net.neoforged.bus.api.SubscribeEvent
        public void commands(RegisterCommandsEvent event) {
            event.getDispatcher().register(Commands.literal("worldender")
                    .then(Commands.literal("status").executes(ctx -> {
                        var world = ctx.getSource().getLevel();
                        boolean active = world.getGameRules().getRule(START_DELETING_WORLD).get();
                        ctx.getSource().sendSuccess(() -> Component.literal("Worldender: active=" + active + ", day=" + DeletionEngine.getDays(world)
                                + ", radius=" + DeletionEngine.getRadius(world) + ", speed=" + DeletionEngine.getSpeed(world) + " blocks/min"), false);
                        return 1;
                    }))
                    .then(Commands.literal("radius")
                            .then(Commands.argument("value", IntegerArgumentType.integer(0, 30_000_000)).requires(s -> s.hasPermission(2)).executes(ctx -> {
                                var world = ctx.getSource().getLevel();
                                DeletionEngine.setRadiusOverride(world, IntegerArgumentType.getInteger(ctx, "value"));
                                ctx.getSource().sendSuccess(() -> Component.literal("Deletion radius override set."), true);
                                return 1;
                            }))
                            .then(Commands.literal("auto").requires(s -> s.hasPermission(2)).executes(ctx -> {
                                DeletionEngine.clearRadiusOverride(ctx.getSource().getLevel());
                                ctx.getSource().sendSuccess(() -> Component.literal("Deletion radius returned to automatic progression."), true);
                                return 1;
                            })))
                    .then(Commands.literal("StartDeletingWorld").requires(s -> s.hasPermission(2))
                            .executes(ctx -> {
                                boolean value = ctx.getSource().getLevel().getGameRules().getRule(START_DELETING_WORLD).get();
                                ctx.getSource().sendSuccess(() -> Component.literal("StartDeletingWorld = " + value), false);
                                return 1;
                            })
                            .then(Commands.literal("true").executes(ctx -> {
                                ctx.getSource().getLevel().getGameRules().getRule(START_DELETING_WORLD).set(true, ctx.getSource().getServer());
                                ctx.getSource().sendSuccess(() -> Component.literal("StartDeletingWorld enabled."), true);
                                return 1;
                            }))
                            .then(Commands.literal("false").executes(ctx -> {
                                ctx.getSource().getLevel().getGameRules().getRule(START_DELETING_WORLD).set(false, ctx.getSource().getServer());
                                ctx.getSource().sendSuccess(() -> Component.literal("StartDeletingWorld disabled."), true);
                                return 1;
                            }))));
        }

        @net.neoforged.bus.api.SubscribeEvent
        public void levelLoad(LevelEvent.Load event) {
            if (event.getLevel() instanceof net.minecraft.server.level.ServerLevel world) DeletionEngine.initializeWorld(world);
        }

        @net.neoforged.bus.api.SubscribeEvent
        public void levelUnload(LevelEvent.Unload event) {
            if (event.getLevel() instanceof net.minecraft.server.level.ServerLevel world) DeletionEngine.unloadWorld(world);
        }

        @net.neoforged.bus.api.SubscribeEvent
        public void levelTick(TickEvent.LevelTickEvent event) {
            if (event.phase != TickEvent.Phase.END || !(event.level instanceof net.minecraft.server.level.ServerLevel world)) return;
            DeletionEngine.tick(world);
        }

        @net.neoforged.bus.api.SubscribeEvent
        public void chunkLoad(ChunkEvent.Load event) {
            if (event.getLevel() instanceof net.minecraft.server.level.ServerLevel world && event.getChunk() instanceof net.minecraft.world.level.chunk.LevelChunk chunk) {
                DeletionEngine.onChunkLoad(world, chunk);
            }
        }

        @net.neoforged.bus.api.SubscribeEvent
        public void chunkUnload(ChunkEvent.Unload event) {
            if (event.getLevel() instanceof net.minecraft.server.level.ServerLevel world && event.getChunk() instanceof net.minecraft.world.level.chunk.LevelChunk chunk) {
                DeletionEngine.onChunkUnload(world, chunk);
            }
        }

        @net.neoforged.bus.api.SubscribeEvent
        public void biomeLoading(BiomeLoadingEvent event) {
            WorldGeneration.addOres(event);
        }
    }
}
