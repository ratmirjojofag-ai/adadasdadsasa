# Worldender 1.5.0 — NeoForge 1.21.1

Minecraft **1.21.1**, NeoForge **21.1.x**, Java **21**.

This is the dedicated NeoForge 1.21.1 source target for Worldender 1.5.0. It contains the same gameplay/data/assets baseline as the Forge 1.20.1 1.5.0 project and declares optional targets for JEI, Jade, Create, Create New Age, Mekanism, AE2 and Create Aeronautics.

### Important
NeoForge 1.21.1 has substantial API changes versus Forge 1.20.1. The loader namespace migration is applied where stable, while registry, capability, GUI/menu, worldgen, JEI/Jade and Create API migrations are clearly marked by `NEOFORGE_PORT_STATUS.md` for the first compile pass.

Create Aeronautics is **NeoForge 1.21.1 only** and is not referenced by the Forge 1.20.1 target.

Build with Java 21 using `./gradlew build`.
