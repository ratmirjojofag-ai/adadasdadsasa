# NeoForge 1.21.1 port status

Target: Worldender 1.5.0 / Minecraft 1.21.1 / NeoForge 21.1.x.

This is a dedicated NeoForge source project, not the removed NeoForge 1.20.1 target.

The source and resources come from the 1.5.0 feature set. Because 1.21.1 changes Minecraft and NeoForge APIs, final compilation requires reconciliation of:
- DeferredRegister/DeferredHolder registration APIs
- capabilities / energy APIs
- menu registration and NetworkHooks replacement
- 1.21.1 worldgen holders
- 1.21.1 client event setup
- JEI 19 and Jade 15 API namespaces
- Create 6 / Create New Age / Create Aeronautics APIs

No claim is made that this source snapshot is already a built NeoForge JAR.
